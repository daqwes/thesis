code for paper: "An efficient adaptive MCMC algorithm for Pseudo-Bayesian quantum tomography"
