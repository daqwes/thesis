# experiments

Each experiment is in its own self-contained folder, with the associated `.py` script to be run, the plots in the `.pdf` format and the output data in the `.csv` file. The experiment folder name hopes to succinctly describe its intent. In case it is not clear, one may look at the `.py` file, where a complete description is available above the function signature. 